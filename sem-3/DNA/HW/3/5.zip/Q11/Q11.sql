SELECT c.customerName, c.creditLimit, SUM(od.quantityOrdered * od.priceEach) AS totalOrderedAmount 
FROM Customers c 
JOIN Orders o ON c.customerNumber = o.customerNumber 
JOIN OrderDetails od ON o.orderNumber = od.orderNumber 
GROUP BY c.customerName, c.creditLimit 
HAVING totalOrderedAmount > (c.creditLimit * 0.01);