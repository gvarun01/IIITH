SELECT orderNumber 
FROM Orders 
WHERE orderStatus = 'Pending' AND orderDate < CURDATE() - INTERVAL 1 MONTH; 
DELETE FROM Orders 
WHERE orderStatus = 'Pending' AND orderDate < CURDATE() - INTERVAL 1 MONTH; 