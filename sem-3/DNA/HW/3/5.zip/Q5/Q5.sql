CREATE VIEW ShippedOrders AS 
SELECT o.orderNumber, o.orderDate, o.shippedDate, c.customerName, e.employeeNumber 
FROM Customers c 
INNER JOIN Orders o ON c.customerNumber = o.customerNumber 
INNER JOIN Employees e ON c.salesRepEmployeeNumber = e.employeeNumber 
WHERE o.orderStatus = "Shipped";
SELECT * FROM ShippedOrders;