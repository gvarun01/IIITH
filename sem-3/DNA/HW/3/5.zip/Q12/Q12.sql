SELECT employeeNumber, firstName, lastName 
FROM Employees 
WHERE employeeNumber NOT IN 
(SELECT DISTINCT reportsTo FROM Employees WHERE reportsTo IS NOT NULL); 