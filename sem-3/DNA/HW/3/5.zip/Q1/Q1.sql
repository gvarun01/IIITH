SELECT c.customerName, SUM(q.quantityOrdered * q.priceEach) AS TotalSpent 
FROM Customers AS c 
INNER JOIN Orders ON c.customerNumber = Orders.customerNumber 
INNER JOIN OrderDetails as q ON Orders.orderNumber = q.orderNumber 
GROUP BY c.customerNumber;