SELECT customerName 
FROM Customers 
WHERE customerNumber NOT IN 
(SELECT DISTINCT customerNumber FROM Orders);