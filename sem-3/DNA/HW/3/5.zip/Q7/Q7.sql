SELECT p.productName 
FROM Products p 
JOIN (SELECT productLine, AVG(quantityInStock) AS avgStock FROM Products GROUP BY productLine) AS avgStockPerLine 
ON p.productLine = avgStockPerLine.productLine 
WHERE p.quantityInStock > avgStockPerLine.avgStock;