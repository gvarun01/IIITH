CREATE VIEW CustomerPaymentHistory AS 
SELECT c.customerName, o.orderNumber, p.paymentDate, p.amount 
FROM Customers c 
JOIN Orders o ON c.customerNumber = o.customerNumber 
JOIN Payments p ON c.customerNumber = p.customerNumber;
SELECT * FROM CustomerPaymentHistory;