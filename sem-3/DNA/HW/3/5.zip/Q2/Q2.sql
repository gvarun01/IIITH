SELECT p.productName, SUM(od.priceEach * od.quantityOrdered) AS TotalSales 
FROM OrderDetails AS od 
INNER JOIN Products AS p ON od.productCode = p.productCode 
GROUP BY od.productCode 
ORDER BY SUM(od.priceEach * od.quantityOrdered) 
DESC LIMIT 5;