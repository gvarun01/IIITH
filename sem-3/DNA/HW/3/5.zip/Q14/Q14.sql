SELECT c.customerName, c.postalCode, c.city 
FROM Customers c 
WHERE c.postalCode IN (SELECT postalCode FROM Offices); 