SELECT c.customerName, SUM(od.quantityOrdered * od.priceEach) AS totalPurchasedAmount 
FROM Customers c 
JOIN Orders o ON c.customerNumber = o.customerNumber 
JOIN OrderDetails od ON o.orderNumber = od.orderNumber 
GROUP BY c.customerName 
ORDER BY totalPurchasedAmount 
DESC LIMIT 1;