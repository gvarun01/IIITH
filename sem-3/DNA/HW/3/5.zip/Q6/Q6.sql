SELECT e.employeeNumber AS EmployeeID, e.firstName AS EmployeeFirstName, e.lastName AS EmployeeLastName, c.customerNumber AS CustomerID, c.customerName AS CustomerName 
FROM Employees e 
JOIN Customers c ON e.employeeNumber = c.salesRepEmployeeNumber;