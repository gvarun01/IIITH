SELECT productName, productCode 
FROM Products 
GROUP BY productName, productCode 
HAVING COUNT(DISTINCT productVendor) > 1;