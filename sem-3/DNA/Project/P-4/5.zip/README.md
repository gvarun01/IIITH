# BondBrothers Minecraft Database Management System
Team ID: 5

## Overview
This application provides a command-line interface for managing a Minecraft-themed database, allowing players and game developers to interact with various game-related features.

# Roles and Functionality
Here is the list of commands that may be executed:
(Please choose a role of either 'player' or 'game developer' after running the script)

## Player Role Commands

### World Management
**Show My Worlds**
   - Displays a list of worlds owned by the player
   - Shows details like spawn coordinates, gamemode, and difficulty

**Add New World**
   - Allows players to create a new world
   - Specify world name, gamemode, difficulty, and other settings
   - Assigns the player's pid as Owner pid

**Delete World**
   - Remove a world from the player's collection
   - Requires ownership verification

**Update Spawn Point**
   - Modify the spawn coordinates for a specific world

### Social Features
**Show Friends**
   - Display a list of the player's friends

**Add New Friend**
   - Connect with other players by their gamertag
   - Establishes a friendship in the database

**Delete Friend**
   - Remove a friend from the player's friend list

### Game Information Commands
**Show Mobs List**
   - Display a comprehensive list of all mobs in the game
   - Shows mob details like name, type, health, and base damage

**Show Flammable Blocks**
   - Retrieve a list of blocks that can catch fire
   - Helps players identify potentially dangerous blocks

**Search Biome**
    - Search for biomes by type
    - Explore different environmental conditions in the game

**Mob With Max Damage**
    - Identify the most powerful mob in the game
    - Shows the mob with the highest base damage

**Search Item**
    - Search for items in the game
    - Find items by name

### Other Player Actions
**Buy Minecoins**
    - Purchase in-game currency
    - Updates player's minecoin balance

**Get Player Stats**
    - View player's gaming statistics
    - Tracks blocks placed, items crafted, and distance traveled

## Game Developer Role Commands

### Management
**Get Mob Kills Data**
   - Retrieve kill statistics for mobs
   - Options to get max, min, average, or total kills

**Get Item Acquisition Data**
   - Analyze item acquisition statistics
   - Options to get max, min, average, or total item acquisitions

**Change Mob Health**
   - Modify the maximum health of a specific mob

**Add Mob Drop**
   - Define new item drops for specific mobs
   - Set drop rates and item details

**Update Item Texture**
   - Replace the texture of a specific item
