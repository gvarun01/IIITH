#include <stdio.h>

#define lli long long int

lli binary_search(lli* L, lli X , lli *iterations);


int main() {
    lli L[32];
    for (int i = 0; i < 32; i++) {
        scanf("%lli", &L[i]);
    }
    lli X;
    scanf("%lld", &X);
    lli iterations = 0;
    lli index = binary_search(L, X, &iterations);
    printf("%lld %lld\n", index,iterations);
    return 0;
}