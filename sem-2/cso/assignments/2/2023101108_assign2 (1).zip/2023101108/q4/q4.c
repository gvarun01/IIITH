#include <stdio.h>

#define lli long long int

lli scores(char *exp, lli n);

int main()
{
    lli n;
    scanf("%lld", &n);
    char exp[n + 1];
    for (int i = 0; i < n; i++)
    {
        scanf(" %c", &exp[i]);
    }
    exp[n] = '\0';
    lli ans = scores(exp, n);
    printf("%lld\n", ans);
    return 0;
}