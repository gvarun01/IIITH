#include<stdio.h>
#include<stdlib.h>

#define lli long long int

lli ncr(lli n, lli r);

int main() {
    lli n, r;
    scanf("%lld %lld", &n, &r);
    lli ans = ncr(n, r);
    printf("%lld\n", ans);
    return 0;
}