#include <stdio.h>

#define lli long long int

lli maxSubarraySum(lli *arr, lli n, lli l, lli r, lli *prefix, lli *dq);

int main()
{
    lli n, l, r;
    scanf("%lld %lld %lld", &n, &l, &r);
    lli arr[n + 1];
    for (int i = 1; i <= n; i++)
    {
        scanf("%lld", &arr[i]);
    }
    lli prefix[n + 1];
    lli dq[2 * n + 1];
    lli ans = maxSubarraySum(arr, n, l, r, prefix, dq);
    printf("%lld\n", ans);
    return 0;
}