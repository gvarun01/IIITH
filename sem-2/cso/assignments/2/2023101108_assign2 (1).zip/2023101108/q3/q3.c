#include <stdio.h>

#define lli long long int

lli evaluatePostfix(char *exp, lli n);

int main()
{
    lli n;
    scanf("%lld", &n);
    char exp[n + 1];
    scanf(" %[^\n]s", exp);
    lli ans = evaluatePostfix(exp, n);
    printf("%lld\n", ans);
    return 0;
}