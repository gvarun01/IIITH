#include <stdio.h>
#include <stdlib.h>

long long int duplicate(long long int *arr, long long int size);

int main()
{
    long long int n;
    scanf("%lld", &n);
    long long int arr[2 * n + 1];
    for (int i = 0; i < 2 * n + 1; i++)
    {
        scanf("%lld", &arr[i]);
    }
    long long int m = duplicate(arr, n);
    printf("%lld\n", m);
    return 0;
}