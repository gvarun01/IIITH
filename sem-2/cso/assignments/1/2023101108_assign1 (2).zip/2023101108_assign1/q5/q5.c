#include <stdio.h>
#include<stdlib.h>

typedef  long long int lli;

void product_except_itself(lli* arr,lli size,lli *ans);

int main()
{
    lli n;
    scanf("%lld",&n);
    lli *arr;
    arr = (lli*)malloc(n*sizeof(lli));
    for(lli x=0;x<n;x++)
    {
        scanf("%lld",&arr[x]);
    }
    lli *ans;
    ans = (lli*)malloc(n*sizeof(lli));
    product_except_itself(arr,n,ans);
    for(int x=0;x<n;x++)
    {
        printf("%lld ",ans[x]);
    }
    printf("\n");
    free(arr);
    free(ans);
    return 0;
}