#include <stdio.h>
#include <stdlib.h>
#define lli long long int

lli sum(lli *arr, lli size);

int main()
{
    lli n;
    scanf("%lld", &n);
    lli *arr = (lli *)malloc(n * sizeof(lli));
    for (int i = 0; i < n; i++)
    {
        scanf("%lld", &arr[i]);
    }
    lli ans = sum(arr, n);
    printf("%lld\n", ans);
    return 0;
}