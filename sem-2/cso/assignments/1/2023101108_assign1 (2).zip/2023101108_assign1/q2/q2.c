#include <stdio.h>
#include <stdlib.h>

#define lli long long int

void rotate(lli *arr, lli size);

int main() {
    lli n;
    scanf("%lld", &n);
    lli *arr = (lli *)malloc(n * sizeof(lli));
    for (int i = 0; i < n; i++) {
        scanf("%lld", &arr[i]);
    }
    rotate(arr, n);
    for (int i = 0; i < n; i++) {
        printf("%lld ", arr[i]);
    }
    printf("\n");
    free(arr);
    return 0;
}
