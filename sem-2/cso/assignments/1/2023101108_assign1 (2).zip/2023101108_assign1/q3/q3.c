#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int is_palindrome(char* str , int n);

int main(){
    char *str = (char*)malloc(sizeof(char) * 100001);
    scanf("%s",str);
    int n = strlen(str);
    int ans = is_palindrome(str,n);
    printf("%d\n",ans);
    return 0;
}